import cv2
import mediapipe as mp
import webrtcvad

mp_face_mesh = mp.solutions.face_mesh
cap = cv2.VideoCapture(0)

with mp_face_mesh.FaceMesh() as face_mesh:
    while True:

        ret, frame = cap.read()
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        result = face_mesh.process(rgb)

        if result.multi_face_landmarks:
            for face_landmarks in result.multi_face_landmarks:
                # detect eye landmarks
                print("Face detected")

        cv2.imshow("Monitoring", frame)

        if cv2.waitKey(1) == 27:
            break

        mp_pose = mp.solutions.pose

with mp_pose.Pose() as pose:
    results = pose.process(image)

    faceCascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
)

faces = faceCascade.detectMultiScale(gray,1.3,5)

if len(faces) > 1:
    print("Multiple people detected")