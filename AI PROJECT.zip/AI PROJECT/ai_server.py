from flask import Flask
import cv2

app = Flask(__name__)

@app.route("/detect")

def detect():

    cap = cv2.VideoCapture(0)

    ret, frame = cap.read()

    if ret:
        return "Face detected"

    return "No face"


if __name__ == "__main__":
    app.run(port=5000)