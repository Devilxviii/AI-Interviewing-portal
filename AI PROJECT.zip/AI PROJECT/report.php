<?php

$data = [];

if(file_exists("alerts.json")){
$data = json_decode(file_get_contents("alerts.json"),true);
}

$total = count($data);

?>

<html>

<body>

<h2>Interview Proctoring Report</h2>

<p>Total Alerts: <?php echo $total; ?></p>

<ul>

<?php
foreach($data as $alert){

echo "<li>".$alert['alert']." at ".$alert['time']."</li>";

}
?>

</ul>

</body>

</html>