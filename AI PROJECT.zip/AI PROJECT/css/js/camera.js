const video = document.getElementById("video");

navigator.mediaDevices.getUserMedia({ video: true })
.then(function(stream) {
    video.srcObject = stream;
})
.catch(function(error) {
    console.log("Camera access denied");
});
setTimeout(function(){
    document.getElementById("alertMessage").innerText =
    "Warning: Looking away detected";
}, 8000);