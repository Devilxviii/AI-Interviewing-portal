const video = document.getElementById("video");
const startBtn = document.getElementById("startBtn");
const endBtn = document.getElementById("endBtn");
const alertList = document.getElementById("alertList");
const timer = document.getElementById("timer");

let stream;
let seconds = 0;
let interval;

startBtn.onclick = async function(){

stream = await navigator.mediaDevices.getUserMedia({video:true});
video.srcObject = stream;

startTimer();

addAlert("Interview started. Monitoring active.");

simulateAlerts();
};

endBtn.onclick = function(){

if(stream){
stream.getTracks().forEach(track => track.stop());
}

clearInterval(interval);

addAlert("Interview ended.");

};

function startTimer(){

interval = setInterval(function(){

seconds++;

let min = Math.floor(seconds/60);
let sec = seconds%60;

timer.innerText =
String(min).padStart(2,'0') + ":" +
String(sec).padStart(2,'0');

},1000);

}

function addAlert(message){

let li = document.createElement("li");
li.innerText = message;

alertList.appendChild(li);

}

function simulateAlerts(){

setTimeout(()=>{
addAlert("Warning: Looking away detected");
},8000);

setTimeout(()=>{
addAlert("Warning: Multiple faces detected");
},15000);

}