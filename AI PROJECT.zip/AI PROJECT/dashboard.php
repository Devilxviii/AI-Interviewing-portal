<?php
$data = [];

if(file_exists("alerts.json")){
$data = json_decode(file_get_contents("alerts.json"),true);
}
?>

<html>

<head>
<title>Recruiter Dashboard</title>
</head>

<body>

<h2>Live Interview Alerts</h2>

<table border="1" cellpadding="10">

<tr>
<th>Alert</th>
<th>Time</th>
</tr>

<?php
foreach($data as $alert){

echo "<tr>";
echo "<td>".$alert['alert']."</td>";
echo "<td>".$alert['time']."</td>";
echo "</tr>";

}
?>

</table>

</body>
</html>